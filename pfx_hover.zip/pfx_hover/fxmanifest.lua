fx_version 'cerulean'
game 'gta5'

description "helicopter-hover-script"

client_scripts {
	'client.lua',
}
