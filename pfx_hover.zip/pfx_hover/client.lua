local PERPGamer_HoverOn = false

-- Configure allowed spawn codes
local AllowedHeliSpawnCodes = {
    "superswat", -- Add allowed spawn codes here
}

-- Check if the vehicle is allowed
local function IsAllowedHeli(veh)
    local model = GetEntityModel(veh)
    for _, code in ipairs(AllowedHeliSpawnCodes) do
        if model == GetHashKey(code) then
            return true
        end
    end
    return false
end

RegisterCommand('pfx', function()
    local ped = PlayerPedId()
    local ego = GetVehiclePedIsIn(ped, true)

    -- Ensure the notifications that allowed or not allowed 
    if GetVehicleClass(ego) == 15 and IsAllowedHeli(ego) then
        PERPGamer_HoverOn = not PERPGamer_HoverOn

        if PERPGamer_HoverOn then
            Citizen.CreateThread(function()
                HelpMessage('Hover mode is on', false, true, 8000)
                while GetVehiclePedIsIn(ped, true) == ego and PERPGamer_HoverOn and 
                      GetHeliMainRotorHealth(ego) > 0 and GetHeliTailRotorHealth(ego) > 0 and 
                      GetVehicleEngineHealth(ego) > 0 do
                    Citizen.Wait(0)
                    local currentvelocity = GetEntityVelocity(ego)
                    SetEntityVelocity(ego, currentvelocity.x, currentvelocity.y, 0.0)
                end
                HelpMessage('Hover mode off', false, true, 8000)
                PERPGamer_HoverOn = false
            end)
        else
            HelpMessage('Hover mode off', false, true, 8000)
        end
    else
        HelpMessage('This vehicle does not support hover mode', false, true, 8000)
    end
end)

RegisterKeyMapping('pfx', 'Heli Hover', 'keyboard', '')

function HelpMessage(msg, thisFrame, beep, duration)
    AddTextEntry('PERPHelpNotification', msg)

    if thisFrame then
        DisplayHelpTextThisFrame('PERPHelpNotification', false)
    else
        if beep == nil then beep = true end
        BeginTextCommandDisplayHelp('PERPHelpNotification')
        EndTextCommandDisplayHelp(0, false, beep, duration or -1)
    end
end

