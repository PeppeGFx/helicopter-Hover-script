
# How to use
To use this all you have to do is /pfx 
add a key in ESC, settings, keybinds, and FiveM.

